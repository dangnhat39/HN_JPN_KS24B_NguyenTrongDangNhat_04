#include <stdio.h>  
#include <stdlib.h>  
#include "userFunctions.h"  

int main(int argc, char *argv[]) {  
    int choice;  
    do {  
        showMainMenu();  
        scanf("%d", &choice);  

        switch (choice) {  
            case 1:  
                showAdminMenu();  
                break;  
            case 2:  
                showUserLoginScreen();  
                break;  
            case 0:  
                printf("Exiting the program...\n");  
                exit(0);  
            default:  
                printf("Invalid choice! Please try again.\n");  
                break;  
        }  
    } while (choice != 0);  
    return 0;  
}